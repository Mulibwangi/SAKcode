#!/usr/bin/env python3
"""Reproduce the scoped algebraic/numerical CPMF audit, not a physical proof."""
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import json
import platform
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy
import sklearn

SEED = 20261013
ROOT = Path(__file__).resolve().parent


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def dump(path, obj):
    path.write_text(json.dumps(obj, indent=2, allow_nan=False), encoding='utf-8')


def angle(x, y, G=None):
    if G is None:
        G = np.eye(len(x))
    c = np.real(x.conj() @ G @ y)
    c /= np.sqrt(np.real(x.conj() @ G @ x) * np.real(y.conj() @ G @ y))
    return float(np.arccos(np.clip(c, -1, 1)))


def relnorm(x, p):
    return float(np.linalg.norm(x-p) / np.linalg.norm(p))


def unitary(rng, n):
    z = rng.normal(size=(n, n)) + 1j*rng.normal(size=(n, n))
    q, _ = np.linalg.qr(z)
    return q


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', default=str(ROOT/'audit_results'))
    args = parser.parse_args()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(SEED)
    results = {}

    # 1. Adjoint and actual recovery are different operations.
    p = np.array([1., 2., 3.])
    T = 2*np.eye(3)
    B = np.linalg.pinv(T)
    orth_errors = []
    for _ in range(100):
        q, _ = np.linalg.qr(rng.normal(size=(6, 6)))
        z = rng.normal(size=6)
        orth_errors.append(relnorm(q.T@q@z, z))
    proj = np.diag([1., 1., 0.])
    z = np.array([1., 2., 7.])
    swap = np.array([[0., 1.], [1., 0.]])
    labels = np.eye(2)
    true_targets = np.eye(2)
    forward = swap@labels
    results['roundtrip'] = {
        'scaled_map_adjoint_relative_error': relnorm(T.T@T@p, p),
        'scaled_map_pseudoinverse_relative_error': relnorm(B@T@p, p),
        'orthogonal_controls': len(orth_errors),
        'max_orthogonal_relative_error': max(orth_errors),
        'projection_full_state_relative_error': relnorm(proj@proj@z, z),
        'projection_preserved_observable_error': float(np.linalg.norm((proj@proj@z-z)[:2])),
        'wrong_label_map_cycle_error': float(np.linalg.norm(swap.T@swap@labels-labels)),
        'wrong_label_map_forward_accuracy': float(np.mean(np.argmax(forward, axis=0)==np.argmax(true_targets, axis=0))),
        'adjoint_cycle_operator_idempotency_defect': float(np.linalg.norm((T.T@T)@(T.T@T)-T.T@T, 2)),
    }
    assert results['roundtrip']['scaled_map_adjoint_relative_error'] == 3
    assert max(orth_errors) < 1e-10
    assert results['roundtrip']['wrong_label_map_forward_accuracy'] == 0

    # 2. An independently fixed output perturbation reveals inverse brittleness.
    brittle = []
    for epsilon in np.logspace(0, -8, 9):
        T = np.diag([1., epsilon])
        x = np.array([1., 0.])
        dc = np.array([0., 1e-6])
        dx = np.linalg.solve(T, dc)
        brittle.append(dict(epsilon=float(epsilon),
                            smallest_singular_value=float(np.linalg.svd(T, compute_uv=False)[-1]),
                            measured_amplification=float(np.linalg.norm(dx)/np.linalg.norm(dc)),
                            reconstruction_error=float(np.linalg.norm(dx)),
                            angle_radians=angle(x, x+dx)))
    pd.DataFrame(brittle).to_csv(out/'brittleness.csv', index=False)
    assert all(np.isclose(r['measured_amplification'], 1/r['epsilon']) for r in brittle)
    results['brittleness'] = {'rows': brittle, 'scope': 'exact linear inverse sensitivity, not a trained semantic model'}

    # 3. Charts require transformed metrics and weighted adjoints.
    x = np.array([1., 0.])
    y = np.array([np.cos(.1), np.sin(.1)])
    A = np.diag([1., 100.])
    Ai = np.linalg.inv(A)
    G = Ai.T@Ai
    chart_rows = []
    for trial in range(300):
        q1, _ = np.linalg.qr(rng.normal(size=(4, 4)))
        q2, _ = np.linalg.qr(rng.normal(size=(4, 4)))
        A = q1@np.diag(10**rng.uniform(-1, 1, 4))@q2.T
        q1, _ = np.linalg.qr(rng.normal(size=(4, 4)))
        q2, _ = np.linalg.qr(rng.normal(size=(4, 4)))
        C = q1@np.diag(10**rng.uniform(-1, 1, 4))@q2.T
        Ai, Ci = np.linalg.inv(A), np.linalg.inv(C)
        Gp, Gc = Ai.T@Ai, Ci.T@Ci
        T = rng.normal(size=(4, 4))
        Tp = C@T@Ai
        actual_adjoint = np.linalg.solve(Gp, Tp.T@Gc)
        expected_adjoint = A@T.T@Ci
        u, v = rng.normal(size=(2, 4))
        chart_rows.append(dict(trial=trial,
                               corrected_angle_error=abs(angle(u,v)-angle(A@u,A@v,Gp)),
                               naive_angle_error=abs(angle(u,v)-angle(A@u,A@v)),
                               weighted_adjoint_relative_error=float(np.linalg.norm(actual_adjoint-expected_adjoint)/np.linalg.norm(expected_adjoint)),
                               naive_adjoint_relative_error=float(np.linalg.norm(Tp.T-expected_adjoint)/np.linalg.norm(expected_adjoint))))
    pd.DataFrame(chart_rows).to_csv(out/'charts.csv', index=False)
    results['charts'] = {
        'fixed_original_angle': angle(x,y),
        'fixed_scaled_naive_angle': angle(np.diag([1.,100.])@x,np.diag([1.,100.])@y),
        'fixed_metric_corrected_angle': angle(np.diag([1.,100.])@x,np.diag([1.,100.])@y,G),
        'random_charts': len(chart_rows),
        'max_corrected_angle_error': max(r['corrected_angle_error'] for r in chart_rows),
        'max_weighted_adjoint_relative_error': max(r['weighted_adjoint_relative_error'] for r in chart_rows),
        'max_naive_angle_error': max(r['naive_angle_error'] for r in chart_rows),
    }
    assert results['charts']['max_corrected_angle_error'] < 1e-9
    assert results['charts']['max_weighted_adjoint_relative_error'] < 1e-9

    # 4. Energy identity: test sign, scalar reparameterization and independent cost.
    t = np.linspace(0, 2*np.pi, 10001)
    theta = .2*np.ones_like(t)
    kappa = .5+.25*np.sin(t)
    kappa_dot = .25*np.cos(t)
    quoted = theta**2*kappa_dot
    path_theta = .2+.1*np.sin(t)
    path_dot = .1*np.cos(t)
    path_cost = float(np.trapezoid(path_dot**2, t))
    results['energy_expression'] = {
        'theta_dimensionless': True, 'kappa_dimensionless': True,
        'rhs_dimension': '1/time', 'physical_energy_dimension': 'mass*length^2/time^2',
        'min_quoted_expression': float(quoted.min()),
        'max_quoted_expression': float(quoted.max()),
        'fraction_negative_sampled': float(np.mean(quoted < -1e-12)),
        'time_reparameterization_s_over_t': 10,
        'quoted_value_t_at_zero': float(quoted[0]),
        'quoted_value_s_at_zero': float(quoted[0]/10),
        'historical_path_cost_constant_kappa': path_cost,
        'quoted_expression_constant_kappa': 0.,
        'quadratic_doubling_ratio': float((2*.2)**2/.2**2),
        'verdict': 'not a generally positive, parameter-independent energy identity; model-specific coupling remains undefined/unvalidated',
    }
    assert quoted.min() < 0
    assert path_cost > .03
    pd.DataFrame({'t':t,'theta':theta,'kappa':kappa,'quoted_expression':quoted,
                  'path_theta':path_theta,'path_cost_rate':path_dot**2}).to_csv(out/'energy_traces.csv',index=False)

    # 5. Scalar separability is an interaction test, not a Riemann tensor.
    mixed = []
    for _ in range(1000):
        t0,r0 = rng.uniform(-2,2,2)
        h,k = rng.uniform(.1,1,2)
        def f(ti,ri): return np.sin(ti)+ri**2
        def mixed_difference(fun):
            return (fun(t0+h,r0+k)-fun(t0+h,r0)-fun(t0,r0+k)+fun(t0,r0))/(h*k)
        mixed.append([mixed_difference(f),mixed_difference(lambda ti,ri:f(ti,ri)+.5*ti*ri)])
    mixed = np.asarray(mixed)
    results['interaction_control'] = {'rectangles':1000,
        'max_separable_mixed_derivative_magnitude':float(np.max(np.abs(mixed[:,0]))),
        'max_positive_control_error_from_half':float(np.max(np.abs(mixed[:,1]-.5))),
        'intrinsic_geometric_curvature_tested':False}
    assert np.max(np.abs(mixed[:,0])) < 1e-10
    assert np.max(np.abs(mixed[:,1]-.5)) < 1e-10

    # 6. Constraint contraction is different from refinement of resolution.
    ref_rows = []
    x0=.75
    for n in 2**np.arange(0,7):
        bound=1/n
        shrunk=float(np.clip(x0,-bound,bound))
        grid_spacing=.25/n
        grid_x=float(np.round(x0/grid_spacing)*grid_spacing)
        ref_rows.append(dict(n=int(n),bound=float(bound),old_state=x0,
                             shrunk_state=shrunk,minimum_distortion=abs(x0-shrunk),
                             finer_grid_distortion=abs(x0-grid_x)))
    state=2.
    slip=.001
    accepted=0
    violations=0
    for _ in range(5000):
        candidate=state+rng.normal(0,.2)
        old_e=state**2
        cand_e=candidate**2
        if cand_e <= old_e+slip:
            state=candidate
            accepted+=1
            violations += int(state**2 > old_e+slip+1e-12)
    proxy_states=.5**np.arange(0,11)
    results['refinement_zip_tie'] = {'refinements':ref_rows,'proposals':5000,
        'accepted_proposals':accepted,'backslip_limit':slip,'accepted_guard_violations':violations,
        'proxy_initial_cost':float(proxy_states[0]**2),'proxy_final_cost':float(proxy_states[-1]**2),
        'referent_initial_error':float((proxy_states[0]-1)**2),
        'referent_final_error':float((proxy_states[-1]-1)**2),
        'conclusion':'monotonicity guards can protect their declared score while losing an independent referent'}
    pd.DataFrame(ref_rows).to_csv(out/'refinement.csv',index=False)
    assert violations == 0
    assert max(r['finer_grid_distortion'] for r in ref_rows)==0

    # 7. Same marginal gauges, different actual conjunctions.
    tas=[]
    n=100000
    gates_ind=rng.random((n,3))<.5
    common=rng.random(n)<.5
    gates_corr=np.column_stack([common,common,common])
    a=rng.random(n)<.5
    gates_disjoint=np.column_stack([a,~a,rng.random(n)<.5])
    for name,gates,exact in [('independent',gates_ind,.125),('correlated',gates_corr,.5),('disjoint',gates_disjoint,0.)]:
        marg=gates.mean(axis=0)
        p0=float(marg[0]); p1=float(gates[gates[:,0],1].mean())
        first_two=gates[:,0]&gates[:,1]
        p2=float(gates[first_two,2].mean()) if first_two.any() else 0.
        joint=float(gates.all(axis=1).mean())
        tas.append(dict(world=name,n=n,tau=float(marg[0]),alpha=float(marg[1]),sigma=float(marg[2]),
                        marginal_product=float(marg.prod()),joint_success=joint,
                        conditional_chain=p0*p1*p2,exact_joint=exact,
                        exact_marginal_product=.125))
    pd.DataFrame(tas).to_csv(out/'tas.csv',index=False)
    results['tas']={'worlds':tas,'verdict':'universal product of marginals fails; conditional chain rule survives'}
    assert all(abs(r['joint_success']-r['conditional_chain'])<1e-12 for r in tas)

    # 8. Gram spectral agreement and conditional robustness.
    spectra=[]
    for trial in range(1000):
        m,n=[(8,5),(5,8),(6,6)][trial%3]
        T=(rng.normal(size=(m,n))+1j*rng.normal(size=(m,n)))/np.sqrt(2)
        ep=np.linalg.eigvalsh(T.conj().T@T)[-min(m,n):]
        ec=np.linalg.eigvalsh(T@T.conj().T)[-min(m,n):]
        spectra.append(float(np.max(np.abs(ep-ec))/max(1.,np.max(ep))))
    robust=[]
    for trial in range(500):
        q1,q2=unitary(rng,5),unitary(rng,5)
        T=q1@np.diag(np.linspace(.3,1.5,5))@q2.conj().T
        E=rng.normal(size=(5,5))+1j*rng.normal(size=(5,5))
        E*=.05/np.linalg.norm(E,2)
        smin=float(np.linalg.svd(T+E,compute_uv=False)[-1])
        gain=float(np.linalg.norm(np.linalg.inv(T+E),2))
        robust.append(dict(trial=trial,smallest_singular_value=smin,inverse_gain=gain))
    pd.DataFrame(robust).to_csv(out/'robustness_bound.csv',index=False)
    results['spectral_controls']={'gram_maps':1000,'max_relative_positive_spectrum_discrepancy':max(spectra),
        'bounded_perturbations':500,'singular_value_lower_bound':.25,
        'min_observed_smallest_singular_value':min(r['smallest_singular_value'] for r in robust),
        'inverse_gain_upper_bound':4.,'max_observed_inverse_gain':max(r['inverse_gain'] for r in robust)}
    assert max(spectra)<1e-10
    assert min(r['smallest_singular_value'] for r in robust)>=.25-1e-10
    assert max(r['inverse_gain'] for r in robust)<=4+1e-10

    # 9. Every finite gap can be positive while the limit is zero.
    gaps=[]
    for N in 2**np.arange(3,10):
        gap=float(4*np.sin(np.pi/N)**2)
        # Check small matrices against an eigensolver too.
        if N<=64:
            shift=np.roll(np.eye(N),1,axis=0)
            eig=np.linalg.eigvalsh(2*np.eye(N)-shift-shift.T)
            assert np.isclose(eig[1],gap,rtol=1e-9,atol=1e-12)
        gaps.append(dict(N=int(N),fixed_spacing_volume_gap=gap,fixed_length_rescaled_gap=N**2*gap))
    pd.DataFrame(gaps).to_csv(out/'gap_limits.csv',index=False)
    amplitudes=np.logspace(0,-8,9)
    H=np.diag([0.,1.,2.])
    quadratic=[float((np.array([0.,a,0.])@H@np.array([0.,a,0.]))/2) for a in amplitudes]
    results['gap_limits']={'graph_rows':gaps,
        'transport_gram_gaps':[float(r['epsilon']**2) for r in brittle],
        'quadratic_form_amplitudes':amplitudes.tolist(),'quadratic_form_costs':quadratic,
        'unit_rayleigh_gap':1.,'mass_gap_proved':False,
        'conclusion':'finite positivity supplies no uniform volume bound or minimum unnormalised amplitude cost'}

    # 10. Gauge transformations preserve observables; a projector update need not.
    psi=np.array([1.,1.])/np.sqrt(2)
    rho=np.outer(psi,psi)
    X=np.array([[0.,1.],[1.,0.]])
    baseline=float(np.trace(rho@X).real)
    gauge_errors=[]
    for _ in range(300):
        U=unitary(rng,2)
        val=np.trace((U@rho@U.conj().T)@(U@X@U.conj().T)).real
        gauge_errors.append(abs(float(val)-baseline))
    P=np.diag([1.,0.])
    projected=P@rho@P
    projected/=np.trace(projected)
    results['gauge_projection']={'gauge_changes':300,'max_expectation_change':max(gauge_errors),
        'fixed_laboratory_expectation_before_projection':baseline,
        'fixed_laboratory_expectation_after_projection':float(np.trace(projected@X).real),
        'physical_collapse_theory_tested':False}
    assert max(gauge_errors)<1e-10

    # 11. Richer witnesses distinguish isospectral fixed-point algebras.
    original=ROOT/'original_sources/christian_unseen_environment_record_test_v1.py'
    env=load_module(original,'original_environment_audit')
    spectrum_errors=[env.spectrum_error(g) for g in [.05,1.,20.]]
    witness=[]
    def commutator_max(basis):
        mats=[basis[:,j].reshape((4,4),order='F') for j in range(4)]
        return max(float(np.linalg.norm(a@b-b@a,'fro')) for a in mats for b in mats)
    for trial in range(200):
        U=unitary(rng,4)
        for system,jumps in env.SYSTEMS.items():
            rotated=[U@J@U.conj().T for J in jumps]
            L=env.lindblad_super_system(rotated,[1.,1.,1.])
            for noise_level in [0.,.01]:
                noise=rng.normal(size=L.shape)+1j*rng.normal(size=L.shape)
                noise*=noise_level/np.linalg.norm(noise,2)
                _,singular,Vh=np.linalg.svd(L+noise)
                basis=Vh.conj().T[:,-4:]
                score=commutator_max(basis)
                classification='A_anticommuting' if score>.2 else 'C_commuting_fusion'
                witness.append(dict(trial=trial,system=system,noise_operator_norm=noise_level,
                                    commutator_max=score,predicted=classification,
                                    correct=int(classification==system),fixed_dimension_exact=int(np.sum(singular<1e-9)) if noise_level==0 else -1))
    pd.DataFrame(witness).to_csv(out/'algebra_witness.csv',index=False)
    group=pd.DataFrame(witness).groupby(['system','noise_operator_norm']).agg(
        accuracy=('correct','mean'),min_commutator=('commutator_max','min'),max_commutator=('commutator_max','max'),cases=('correct','size')).reset_index()
    results['isospectral_witness']={'original_gamma_spectrum_errors':spectrum_errors,
        'random_rotations':200,'classification_threshold':.2,'noise_bound':.01,
        'groups':group.to_dict(orient='records'),
        'scope':'full-generator algebra witness; not the previously failed random-probe algebra classifier'}
    assert max(spectrum_errors)<1e-10

    # Save checks with computed numbers rather than success labels alone.
    metadata={'seed':SEED,'python':platform.python_version(),'numpy':np.__version__,
        'scipy':scipy.__version__,'pandas':pd.__version__,'sklearn':sklearn.__version__,
        'provenance':'actual local execution on synthetic and exact mathematical substrates',
        'hashes':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
          for p in [Path(__file__),ROOT/'CPMF_test_protocol_2026-10-13.md',
                    ROOT/'original_sources/cpmf_qms_smoke_test_v7_christian_baseline.py',original]}}
    dump(out/'algebra_results.json',results)
    dump(out/'metadata.json',metadata)

    fig,axes=plt.subplots(2,2,figsize=(11,7.8),layout='constrained')
    ax=axes[0,0]
    ax.loglog([r['epsilon'] for r in brittle],[r['measured_amplification'] for r in brittle],'o-',color='#b34e3c')
    ax.set(xlabel='Smallest singular value',ylabel='Inverse perturbation amplification',title='Recovery becomes brittle as the seam narrows')
    ax.grid(alpha=.2)
    ax=axes[0,1]
    positions=np.arange(3)
    ax.bar(positions-.16,[r['joint_success'] for r in tas],.32,label='Actual joint success',color='#224f65')
    ax.bar(positions+.16,[r['marginal_product'] for r in tas],.32,label='Product of marginal gauges',color='#c3a55a')
    ax.set(xticks=positions,xticklabels=['Independent','Correlated','Disjoint'],ylabel='Success probability',title='TAS needs a dependence model')
    ax.legend(fontsize=8)
    ax=axes[1,0]
    ax.loglog([r['N'] for r in gaps],[r['fixed_spacing_volume_gap'] for r in gaps],'o-',label='Growing volume; spacing fixed')
    ax.loglog([r['N'] for r in gaps],[r['fixed_length_rescaled_gap'] for r in gaps],'o-',label='Fixed length; grid refined')
    ax.set(xlabel='Number of sites N',ylabel='First nonzero Laplacian eigenvalue',title='Finite gaps do not establish a volume limit')
    ax.grid(alpha=.2)
    ax.legend(fontsize=8)
    ax=axes[1,1]
    ax.plot(t,quoted,color='#b34e3c')
    ax.axhline(0,color='#777',lw=.7)
    ax.set(xlabel='Time parameter',ylabel='Quoted expression (arbitrary rate units)',title=r'$\theta^2\dot{\kappa}$ changes sign')
    fig.suptitle('CPMF audit · executed controls and counterexamples · 13 October 2026',fontsize=13)
    fig.savefig(out/'audit_overview.png',dpi=180)
    plt.close(fig)
    print(json.dumps({k:v for k,v in results.items() if k in ['roundtrip','charts','energy_expression','spectral_controls','isospectral_witness']},indent=2))


if __name__=='__main__':
    main()
