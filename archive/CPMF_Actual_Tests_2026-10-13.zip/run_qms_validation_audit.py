#!/usr/bin/env python3
"""Grouped validation selection and untouched test paths for recovered v7."""
from __future__ import annotations
import argparse
import contextlib
import hashlib
import importlib.util
import json
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score,average_precision_score
from sklearn.model_selection import GroupShuffleSplit
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

ROOT=Path(__file__).resolve().parent


def load_original(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def models(seed):
    return {
        'logreg':make_pipeline(StandardScaler(),LogisticRegression(max_iter=600,class_weight='balanced')),
        'rf':RandomForestClassifier(n_estimators=70,max_depth=5,min_samples_leaf=8,class_weight='balanced',random_state=seed,n_jobs=1),
    }


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--out',default=str(ROOT/'audit_results'))
    args=ap.parse_args()
    out=Path(args.out)
    out.mkdir(parents=True,exist_ok=True)
    v7_path=ROOT/'original_sources/cpmf_qms_smoke_test_v7_christian_baseline.py'
    v7=load_original('original_v7_validation',v7_path)
    columns={
        'physics':v7.CHRISTIAN_NATURAL_BASELINE,
        'combined':v7.CHRISTIAN_NATURAL_BASELINE+v7.CPMF_RELATIONAL_EXTRA,
        'combined_no_invalidity':v7.CHRISTIAN_NATURAL_BASELINE+v7.CPMF_RELATIONAL_EXTRA_NO_INVALIDITY,
        'time_only':['t'],
        'shuffled':v7.CHRISTIAN_NATURAL_BASELINE+v7.CPMF_RELATIONAL_EXTRA,
    }
    rows=[]; split_rows=[]; skips=[]
    for run in range(20):
        seed=202610130+1009*run
        rng=np.random.default_rng(seed)
        T,horizon=20,4
        raw=pd.concat([v7.sample_path(rng,T,pid) for pid in range(70)],ignore_index=True)
        df=v7.add_features(raw,horizon)
        df=df[df.t<=T-horizon-1].reset_index(drop=True)
        fitval_idx,test_idx=next(GroupShuffleSplit(n_splits=1,test_size=.33,random_state=seed).split(df,groups=df.path_id))
        fitval=df.iloc[fitval_idx].reset_index(drop=True)
        fit_idx,val_idx=next(GroupShuffleSplit(n_splits=1,test_size=.25,random_state=seed+17).split(fitval,groups=fitval.path_id))
        fit=fitval.iloc[fit_idx].reset_index(drop=True)
        val=fitval.iloc[val_idx].reset_index(drop=True)
        test=df.iloc[test_idx].reset_index(drop=True)
        sets=[set(d.path_id) for d in [fit,val,test]]
        assert all(not sets[i]&sets[j] for i in range(3) for j in range(i+1,3))
        assert len(set.union(*sets))==70
        meta={'run':run,'seed':seed,'fit_paths':sorted(map(int,sets[0])),
              'validation_paths':sorted(map(int,sets[1])),'test_paths':sorted(map(int,sets[2])),
              'fit_windows':len(fit),'validation_windows':len(val),'test_windows':len(test),
              'fit_failure_rate':float(fit.future_fail.mean()),'validation_failure_rate':float(val.future_fail.mean()),
              'test_failure_rate':float(test.future_fail.mean())}
        split_rows.append(meta)
        if any(d.future_fail.nunique()<2 for d in [fit,val,test]):
            skips.append({'run':run,'seed':seed,'reason':'single class in at least one split'})
            continue
        selections=[]
        for fs,cols in columns.items():
            yfit=fit.future_fail.to_numpy(dtype=int).copy()
            if fs=='shuffled':
                rng.shuffle(yfit)
            choices=[]
            for name,model in models(seed).items():
                model.fit(fit[cols],yfit)
                score=model.predict_proba(val[cols])[:,1]
                choices.append((float(roc_auc_score(val.future_fail,score)),name,model))
            # Choose using validation only; ties retain the first declared estimator.
            chosen=max(choices,key=lambda x:x[0])
            selections.append((fs,cols,chosen))
        # Only now inspect the test scores of the locked selections.
        for fs,cols,(validation_auc,name,model) in selections:
            predictions=model.predict_proba(test[cols])[:,1]
            rows.append(dict(run=run,seed=seed,feature_set=fs,selected_model=name,
                              validation_auc=validation_auc,
                              test_auc=float(roc_auc_score(test.future_fail,predictions)),
                              test_average_precision=float(average_precision_score(test.future_fail,predictions)),
                              test_failure_rate=float(test.future_fail.mean()),n_features=len(cols),
                              fit_paths=len(sets[0]),validation_paths=len(sets[1]),test_paths=len(sets[2]),test_windows=len(test)))
        print(f'Validation audit completed run {run+1}/20',flush=True)
    frame=pd.DataFrame(rows)
    if frame.empty:
        raise RuntimeError('No valid split; no seeds were replaced')
    frame.to_csv(out/'qms_validation_scores.csv',index=False)
    (out/'qms_validation_splits.json').write_text(json.dumps(split_rows,indent=2),encoding='utf-8')
    aggregate=frame.groupby('feature_set').agg(mean_auc=('test_auc','mean'),std_auc=('test_auc','std'),
        mean_ap=('test_average_precision','mean'),runs=('test_auc','size')).reset_index()
    aggregate.to_csv(out/'qms_validation_aggregate.csv',index=False)
    pivot=frame.pivot(index='run',columns='feature_set',values='test_auc')
    deltas=pd.DataFrame({name:pivot[name]-pivot.physics for name in ['combined','combined_no_invalidity']})
    deltas.to_csv(out/'qms_validation_deltas.csv',index_label='run')
    bootstrap_rng=np.random.default_rng(202610131)
    intervals={}
    for name in deltas:
        values=deltas[name].to_numpy()
        draw=bootstrap_rng.choice(values,size=(25000,len(values)),replace=True).mean(axis=1)
        lo,hi=np.quantile(draw,[.025,.975])
        mean=float(values.mean()); win=float((values>0).mean())
        intervals[name]={'mean_paired_auc_delta':mean,'bootstrap_95_interval':[float(lo),float(hi)],
                          'win_fraction':win,'strict_promotion_pass':bool(mean>.02 and win>=.7 and lo>0)}
    summary={'scope':'synthetic qubit QMS-lite; selection on validation, unseen path test data',
        'runs_requested':20,'runs_scored':int(frame.run.nunique()),'skips':skips,
        'n_paths_per_run':70,'T':20,'horizon':4,'complete_future_windows_only':True,
        'n_total_generated_paths':20*70,'total_scored_test_windows':int(frame[frame.feature_set=='physics'].test_windows.sum()),
        'model_selection':'validation AUC only; no refit after selection',
        'bootstrap_unit':'independently generated complete run, preserving paired feature-set scores',
        'aggregate':aggregate.to_dict(orient='records'),'paired_comparisons':intervals,
        'source_sha256':hashlib.sha256(v7_path.read_bytes()).hexdigest(),
        'runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'limitations':['Generator/thresholds are authored synthetic proxies, not full QMS axioms.',
                      'Raw-invalidity signal can carry direct information about the positivity trigger; no-invalidity comparison is retained.',
                      'Run intervals address Monte Carlo variability in this generator, not uncertainty across real physical systems.']}
    (out/'qms_validation_summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False),encoding='utf-8')
    # Redirect output only, leaving original numerical construction unchanged.
    env_path=ROOT/'original_sources/christian_unseen_environment_record_test_v1.py'
    env=load_original('original_environment_rerun',env_path)
    env.OUT=out/'original_environment'
    env.OUT.mkdir(exist_ok=True)
    with (env.OUT/'execution_stdout.txt').open('w',encoding='utf-8') as log,contextlib.redirect_stdout(log):
        env.main()
    print(json.dumps(summary,indent=2),flush=True)


if __name__=='__main__':
    main()
