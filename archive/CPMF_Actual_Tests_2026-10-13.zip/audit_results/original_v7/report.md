# CPMF/QMS Smoke Test v7 — Christian-natural baseline comparison

Status: **WEAK_PASS_SMALL_INCREMENTAL_CPMF_OVER_CHRISTIAN_BASELINE**

## Purpose
v7 asks whether CPMF-style relational generator features add incremental forecast value beyond a stronger domain-natural physics/QMS baseline.
The label is future analytic-regime failure. The main feature sets exclude the diagnostic scalars used to define that label.

## Key scores
- Christian-natural baseline mean AUC: 0.869
- Combined physics + CPMF mean AUC: 0.879
- Combined without raw-invalidity mean AUC: 0.880
- Position-only mean AUC: 0.516
- Shuffled combined mean AUC: 0.485
- Combined minus Christian mean delta: +0.011
- Combined win-rate over Christian: 75.00%

## Honest interpretation
The CPMF relational additions add a small positive increment, but not enough for a strong promotion.
Treat this as a weak synthetic signal requiring more seeds and a Christian-approved baseline.

## Next step
Ask Christian what he would accept as a natural generator-side baseline and rerun this comparison against that feature set and his preferred coercivity/admissibility diagnostics.