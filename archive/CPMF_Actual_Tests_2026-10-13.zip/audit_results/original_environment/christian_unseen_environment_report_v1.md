# Christian unseen-environment record test v1

## Construction

The original two isospectral Lindblad generators were not modified.

No measurement result was written during the dynamics. The system interacted
unitarily with four fresh environment qubits. All fragments remained uninspected
until the end. We then measured recoverability from one fragment, two fragments,
three fragments and the full environment.

## Spectral control

Maximum A-versus-C spectrum discrepancy:

**5.684e-14**

## Monotonic recovery

- Prefix trace distance monotone in:
  **100.0%** of cases.
- Prefix Holevo information monotone in:
  **100.0%** of cases.

This monotonicity is not imposed by a classical write step. It follows from
inspecting progressively larger portions of the final quantum environment.

## Fixed directions

Mean final values:

| Quantity | Fixed directions | Nonfixed directions |
|---|---:|---:|
| Distinction still local in system | 0.800000 | 0.080722 |
| Full-environment trace distance | 0.679278 | 0.220068 |
| Full-environment Holevo information | 0.423126 | 0.063631 |
| Mean single-fragment trace distance | 0.418150 | 0.102804 |

## Hidden-algebra recovery

On directions fixed in only one generator:

- full-environment trace distance identified the correct algebra owner in
  **100.0%** of cases;
- full-environment Holevo information identified it in
  **100.0%**;
- the average individual fragment identified it in
  **100.0%**.

## Verdict

The record need not be stored in a singled-out classical memory. It can exist as
distributed quantum correlations across an unobserved environment and become
recoverable only when sufficiently many fragments are collected.

The two generators remain spectrally identical, but their different fixed-point
algebras determine which operator distinctions survive locally and which seed a
strong distributed environmental record.

This is an operational model of irreversible record dispersal. It does not prove
Semantic Admissibility or a new fundamental ZipTie law.
