# CPMF executable audit — frozen protocol

Author: David Lee (CPMF project); numerical audit prepared by ChatGPT.
Date: 13 October 2026.

This protocol is written before executing the new tests. It is a protocol lock inside this conversation, not an externally registered preregistration or a claim of unfamiliarity with the algebraic outcomes. Universal claims may be rejected by explicit counterexamples; random matrices and synthetic QMS paths are not empirical observations of meaning or of four-dimensional Yang–Mills theory.

## Definitions and scope

Use finite real or complex Hilbert spaces with specified Euclidean inner products, except when explicitly transforming the metrics. T* denotes the Hilbert adjoint. R denotes a recovery map in this audit only; it must not be confused with David's CPMF relational determination R. In the report, recovery will be written B where possible. The user gates remain A = admissibility, L = lawful closure, Co = coherence/constraint.

Round-trip error: ||BTp-p||/||p||. Forward alignment is scored against an independently declared referent map, not against BTp. Perturbation amplification: ||B delta_c||/||delta_c||. Angle: arccos(p^T G c / sqrt((p^T G p)(c^T G c))). Refinement distortion is distance to a new admissible set. A scalar mixed difference tests interaction, not intrinsic Riemannian curvature.

## Locked tests

1. Adjoint versus inverse: T = 2I, orthogonal positive controls (100 draws), legitimate rank-losing projection, and a wrong but exactly reversible label permutation. Check computed errors; do not equate recovery with meaning or existence.
2. Brittleness: T_epsilon = diag(1, epsilon), epsilon in 10^0 through 10^-8; fixed output perturbation (0, 10^-6). Compare the measured inverse amplification with 1/epsilon and the angle with the intended vector.
3. Chart discipline: a fixed angle under anisotropic scaling, and 300 random nonsingular charts with singular scales between 0.1 and 10. Test the metric-corrected angle and weighted adjoint against transformed originals. Tolerance 10^-9.
4. Energy-expression audit: constant, increasing and decreasing kappa; time reparameterization s = 10t; raw angle scaling; dimensional bookkeeping. Compare the quoted expression with the separately specified historical path-cost proxy integral(dot(theta)^2 dt), with kappa constant. Do not substitute one definition for another to manufacture equality.
5. Interaction control: separable A(t,r) = sin(t)+r^2 and a nonseparable positive control adding 0.5tr, over 1,000 rectangles. Mixed-difference tolerance 10^-10.
6. Refinement/Zip-Tie: shrinking intervals versus nested increasing resolution that preserves an earlier point. Run 5,000 bounded-backslip proposals on a fixed objective; separately show that a decreasing proxy can worsen an independent referent error. A guard passing is implementation correctness, not a new physical law.
7. TAS: 100,000 simulated observations in each of independent, perfectly correlated, and disjoint-gate worlds, all with marginal gate probabilities 1/2. Score joint success, marginal product and the conditional chain rule. Reject a universal marginal-product claim if equal marginals support different joint probabilities.
8. Spectra: 1,000 complex rectangular/square maps; compare the positive spectra of T*T and TT*. Relative tolerance 10^-10. Run 500 invertible-map perturbation cases with smallest singular value 0.3 and perturbation operator norm 0.05; check the 0.25 lower singular bound and inverse amplification bound 4.
9. Gap limits: calculate gaps of T_epsilon*T_epsilon, massless cycle Laplacians for N = 8,...,512, and the fixed-domain rescaled counterparts. Check that no uniform positive lower bound follows from positive finite-size gaps. Also test amplitude scaling of a fixed positive quadratic form. These are counterexample families, not Yang–Mills discretizations.
10. Gauge/projection control: 300 simultaneous unitary changes of state and observable, contrasted with a fixed-laboratory projector update. Gauge expectations must agree within 10^-10. This does not adjudicate interpretations of quantum measurement.
11. Original isospectral QMS/environment test: execute the recovered original 90-case numerical construction without changing its numerical rules; redirect its output directory only. Separately inspect algebra commutators on 200 random unitary rotations with and without measurement noise of operator norm 0.01. Recover the lowest four singular vectors and lock commutator classification threshold at 0.2. This is a different substrate from earlier random-probe v4 and cannot erase its reported robustness failure.
12. Effectiveness: execute original v7 defaults (8 runs, 45 paths, T=16, horizon=3, seed=20260607), recording its test-set model-selection flaw. Then run 20 fresh datasets (70 paths, T=20, horizon=4, seeds 202610130 + 1009*r). Remove all incomplete future windows. Split entire paths into fit/validation/test; test share 0.33, validation share 0.25 of remaining paths. Select between the original logistic and 70-tree random-forest models on validation AUC only. Test feature sets: physics baseline, physics+CPMF, physics+CPMF with raw-invalidity excluded, time-only control, and shuffled-training-label control. Keep model hyperparameters from v7; random forests use one thread for reproducibility. Record every seed, split, model choice, AUC and average precision. Primary paired comparison is physics+CPMF minus physics; no-invalidity is a robustness comparison. Bootstrap paired run deltas 25,000 times; report percentile 95% intervals. Locked promotion rule: mean delta > 0.02, wins in >=70% of scored runs, and paired interval lower limit >0. If a split lacks either label, record and skip without replacing its seed.

## Untestable here

The recovered environment has no trained VLM, GPU model runtime, SIMBad dataset, or independent physical energy measurement. BadSem ASR and CPMF defense effectiveness will be source-verified but not represented as replicated experiments. The supplied text contains no Yang–Mills Hamiltonian, gauge-field measure, renormalization construction or continuum theorem. No mass-gap solution may be inferred from the finite matrix tests.

## Reproducibility

Seed for new algebraic tests: 20261013. Numerical controls and counterexamples are computed, not represented by hard-coded success rows. Save source hashes, package versions, this protocol hash, actual output data and runnable scripts. Do not change thresholds after results are observed.
