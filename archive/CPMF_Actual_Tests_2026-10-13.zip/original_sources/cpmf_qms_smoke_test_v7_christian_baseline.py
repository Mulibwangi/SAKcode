#!/usr/bin/env python3
"""
CPMF/QMS Smoke Test v7: random Lindblad/QMS-lite forecast against a stronger
Christian-natural physics baseline.

Purpose
-------
v6 showed that non-leaking generator-side features forecast later analytic-regime
failure across repeated random Lindblad-style paths. But a simple physical baseline
was already strong. v7 asks the harder question:

    Does the CPMF-style relational feature set beat a serious domain-natural
    generator baseline that a QMS/physics-aware mathematician would plausibly choose?

This remains a synthetic qubit Lindblad/QMS-lite harness. It is not Christian's full
QMS setting: no GNS/KMS theorem, no MLSI estimate, no noncommutative coercivity proof.

Important anti-tautology rule
-----------------------------
The main non-leaking feature sets do NOT include the diagnostic quantities used to
label failure: spectral gap, db_proxy, trace defect, stationary residual, positivity
structure defect. Those are allowed only in the explicit leak benchmark.

Feature-set philosophy
----------------------
- christian_natural_baseline:
    low-dimensional generator quantities that are physically natural: Hamiltonian
    drive, dissipative mass, rates, rate balance, coherent/dissipative ratio,
    smoothness derivatives. This is deliberately strong and non-mystical.

- cpmf_relational_extra:
    cross-relational and path-relational features: second derivatives, ratios,
    curl-like couplings, balance/curvature, anisotropy, log-rate geometry,
    pairwise products between coherent and dissipative coordinates.

- combined_physics_plus_cpmf:
    union of both. CPMF earns useful incremental traction only if this beats the
    Christian-natural baseline reliably, not merely if both are good.

Outputs
-------
- summary.json
- repeated_scores.csv
- aggregate_scores.csv
- incremental_delta.csv
- report.md

Run
---
python3 cpmf_qms_smoke_test_v7_christian_baseline.py \
  --out runs/cpmf_qms_smoke_v7_christian_baseline \
  --n-runs 20 --n-paths 70 --T 20 --horizon 4
"""
from __future__ import annotations

import argparse, json, math
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.linalg import eigvals
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, average_precision_score
from sklearn.model_selection import GroupShuffleSplit
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

SIGMA_X = np.array([[0, 1], [1, 0]], dtype=complex)
SIGMA_Y = np.array([[0, -1j], [1j, 0]], dtype=complex)
SIGMA_Z = np.array([[1, 0], [0, -1]], dtype=complex)
SIGMA_M = np.array([[0, 0], [1, 0]], dtype=complex)
SIGMA_P = np.array([[0, 1], [0, 0]], dtype=complex)


def lindblad_superoperator(H: np.ndarray, jumps: list[tuple[float, np.ndarray]]) -> np.ndarray:
    d = H.shape[0]
    I = np.eye(d, dtype=complex)
    Lsup = -1j * (np.kron(I, H) - np.kron(H.T, I))
    for gamma, L in jumps:
        A = L.conj().T @ L
        Lsup += gamma * (np.kron(L.conj(), L) - 0.5 * np.kron(I, A) - 0.5 * np.kron(A.T, I))
    return Lsup


def liouvillian_gap(Lsup: np.ndarray) -> float:
    ev = eigvals(Lsup)
    decays = sorted([max(0.0, -float(np.real(z))) for z in ev])
    positive = [x for x in decays if x > 1e-7]
    return float(min(positive)) if positive else 0.0


def stationary_state_residual(Lsup: np.ndarray) -> float:
    s = np.linalg.svd(Lsup, compute_uv=False)
    return float(np.min(s))


def trace_preservation_defect(Lsup: np.ndarray) -> float:
    tr = np.array([1, 0, 0, 1], dtype=complex)
    return float(np.linalg.norm(tr @ Lsup))


def softplus(x: np.ndarray) -> np.ndarray:
    return np.log1p(np.exp(-np.abs(x))) + np.maximum(x, 0)


def sample_path(rng: np.random.Generator, T: int, pid: int) -> pd.DataFrame:
    # Random slowly-varying generator coordinates. Some paths drift toward regimes
    # that later violate analytic-gate thresholds. The model must forecast that from
    # generator-side structure, not from the diagnostic gate itself.
    z = rng.normal(0, 0.85, size=7)
    drift = rng.normal(0, 0.060, size=7)
    rows = []
    for t in range(T):
        z = 0.91 * z + drift + rng.normal(0, 0.115, size=7)
        hx, hy, hz = 0.78 * z[0], 0.78 * z[1], 0.48 * z[2]
        gd, gu, gp = 0.012 + softplus(z[3:6]) * 0.30
        raw_invalidity = z[6]
        # Non-Lindblad / positivity-structure failure is deliberately rare but possible.
        if raw_invalidity < -1.70:
            gd = -0.08 * (abs(raw_invalidity) - 1.70)
        H = hx * SIGMA_X + hy * SIGMA_Y + hz * SIGMA_Z
        Lsup = lindblad_superoperator(H, [(gd, SIGMA_M), (gu, SIGMA_P), (gp, SIGMA_Z)])
        gap = liouvillian_gap(Lsup)
        trace_def = trace_preservation_defect(Lsup)
        stat_resid = stationary_state_residual(Lsup)
        pos_def = max(0.0, -min(gd, gu, gp))
        dissipative_mass = gd + gu + gp
        coherent_mass = math.sqrt(hx * hx + hy * hy + hz * hz)
        drive_xy = math.sqrt(hx * hx + hy * hy)
        # Proxy only. Not full KMS/GNS detailed balance.
        db_proxy = abs(math.log((abs(gd) + 1e-4) / (abs(gu) + 1e-4))) * drive_xy / (abs(gd) + abs(gu) + abs(gp) + 1e-4)
        rows.append(dict(
            path_id=pid, t=t,
            hx=hx, hy=hy, hz=hz,
            gamma_down=gd, gamma_up=gu, gamma_dephase=gp,
            raw_invalidity=raw_invalidity,
            coherent_mass=coherent_mass, dissipative_mass=dissipative_mass,
            drive_xy=drive_xy,
            gap=gap, db_proxy=db_proxy, trace_def=trace_def, stat_resid=stat_resid,
            positivity_struct_defect=pos_def,
        ))
    return pd.DataFrame(rows)


def safe_log_ratio(a: pd.Series, b: pd.Series) -> pd.Series:
    return np.log((np.abs(a) + 1e-4) / (np.abs(b) + 1e-4))


def add_features(df: pd.DataFrame, horizon: int) -> pd.DataFrame:
    out = []
    gen_cols = ["hx", "hy", "hz", "gamma_down", "gamma_up", "gamma_dephase", "raw_invalidity"]
    for pid, g in df.groupby("path_id"):
        g = g.sort_values("t").copy()
        for c in gen_cols:
            g[f"d_{c}"] = g[c].diff().fillna(0.0)
            g[f"dd_{c}"] = g[f"d_{c}"].diff().fillna(0.0)
        rates = g[["gamma_down", "gamma_up", "gamma_dephase"]]
        g["rate_ratio_du"] = safe_log_ratio(g["gamma_down"], g["gamma_up"])
        g["rate_ratio_dp"] = safe_log_ratio(g["gamma_down"], g["gamma_dephase"])
        g["rate_ratio_up"] = safe_log_ratio(g["gamma_up"], g["gamma_dephase"])
        g["rate_min"] = rates.min(axis=1)
        g["rate_max"] = rates.max(axis=1)
        g["rate_spread"] = g["rate_max"] - g["rate_min"]
        g["rate_cv"] = rates.std(axis=1) / (np.abs(rates.mean(axis=1)) + 1e-4)
        g["coh_over_diss"] = g["coherent_mass"] / (np.abs(g["dissipative_mass"]) + 1e-4)
        g["ham_anisotropy"] = (np.abs(g["hx"] - g["hy"]) + np.abs(g["hy"] - g["hz"]) + np.abs(g["hz"] - g["hx"])) / (g["coherent_mass"] + 1e-4)
        g["curl_like"] = g["hx"] * g["gamma_up"] - g["hy"] * g["gamma_down"]
        g["curl_dephase"] = g["hz"] * (g["gamma_down"] - g["gamma_up"])
        g["balance_drive"] = g["drive_xy"] * np.abs(g["rate_ratio_du"])
        g["diss_curvature"] = g["dd_gamma_down"].abs() + g["dd_gamma_up"].abs() + g["dd_gamma_dephase"].abs()
        g["ham_curvature"] = g["dd_hx"].abs() + g["dd_hy"].abs() + g["dd_hz"].abs()
        g["path_speed_gen"] = np.sqrt(sum(g[f"d_{c}"] ** 2 for c in gen_cols))
        g["path_accel_gen"] = np.sqrt(sum(g[f"dd_{c}"] ** 2 for c in gen_cols))
        g["coh_diss_product"] = g["coherent_mass"] * g["dissipative_mass"]
        g["xy_phase_pressure"] = g["hx"] * g["d_hy"] - g["hy"] * g["d_hx"]
        g["rate_phase_pressure"] = g["gamma_down"] * g["d_gamma_up"] - g["gamma_up"] * g["d_gamma_down"]
        future, fail_reason = [], []
        for idx in range(len(g)):
            win = g.iloc[idx+1:idx+1+horizon]
            if len(win) == 0:
                future.append(np.nan); fail_reason.append("none"); continue
            gap_fail = bool(win["gap"].min() < 0.42)
            db_fail = bool(win["db_proxy"].max() > 1.25)
            trace_fail = bool(win["trace_def"].max() > 1e-6)
            pos_fail = bool(win["positivity_struct_defect"].max() > 0.001)
            future.append(int(gap_fail or db_fail or trace_fail or pos_fail))
            fail_reason.append("+".join([name for name, val in [("gap", gap_fail), ("db", db_fail), ("trace", trace_fail), ("pos", pos_fail)] if val]) or "none")
        g["future_fail"] = future
        g["future_fail_reason"] = fail_reason
        out.append(g)
    return pd.concat(out, ignore_index=True).dropna(subset=["future_fail"]).reset_index(drop=True)

# Strong domain-natural generator baseline. This is deliberately not weak.
CHRISTIAN_NATURAL_BASELINE = [
    "hx", "hy", "hz", "gamma_down", "gamma_up", "gamma_dephase",
    "coherent_mass", "dissipative_mass", "drive_xy", "coh_over_diss",
    "rate_ratio_du", "rate_ratio_dp", "rate_ratio_up", "rate_min", "rate_max", "rate_spread", "rate_cv",
    "d_hx", "d_hy", "d_hz", "d_gamma_down", "d_gamma_up", "d_gamma_dephase",
]

CPMF_RELATIONAL_EXTRA = [
    "raw_invalidity", "d_raw_invalidity", "dd_raw_invalidity",
    "dd_hx", "dd_hy", "dd_hz", "dd_gamma_down", "dd_gamma_up", "dd_gamma_dephase",
    "ham_anisotropy", "curl_like", "curl_dephase", "balance_drive", "diss_curvature", "ham_curvature",
    "path_speed_gen", "path_accel_gen", "coh_diss_product", "xy_phase_pressure", "rate_phase_pressure",
]

# Ablated CPMF extra: remove explicit invalidity signal, since a critic may call it too close to positivity failure.
CPMF_RELATIONAL_EXTRA_NO_INVALIDITY = [c for c in CPMF_RELATIONAL_EXTRA if "raw_invalidity" not in c]

FEATURE_SETS = {
    "position_only": ["t"],
    "christian_natural_baseline": CHRISTIAN_NATURAL_BASELINE,
    "cpmf_relational_extra_only": CPMF_RELATIONAL_EXTRA,
    "cpmf_extra_no_invalidity_only": CPMF_RELATIONAL_EXTRA_NO_INVALIDITY,
    "combined_physics_plus_cpmf": CHRISTIAN_NATURAL_BASELINE + CPMF_RELATIONAL_EXTRA,
    "combined_no_invalidity": CHRISTIAN_NATURAL_BASELINE + CPMF_RELATIONAL_EXTRA_NO_INVALIDITY,
    "current_diagnostic_leak": ["gap", "db_proxy", "trace_def", "stat_resid", "positivity_struct_defect"],
}


def score_models(Xtr, ytr, Xte, yte, seed: int, fast: bool) -> dict:
    models = {
        "logreg": make_pipeline(StandardScaler(), LogisticRegression(max_iter=600, class_weight="balanced")),
        "rf": RandomForestClassifier(n_estimators=120 if not fast else 70, max_depth=5, min_samples_leaf=8, class_weight="balanced", random_state=seed, n_jobs=-1),
    }
    if not fast:
        models["hgb"] = HistGradientBoostingClassifier(max_iter=90, learning_rate=0.06, max_leaf_nodes=15, l2_regularization=0.05, random_state=seed)
    best = None
    for name, model in models.items():
        model.fit(Xtr, ytr)
        if hasattr(model, "predict_proba"):
            s = model.predict_proba(Xte)[:, 1]
        else:
            s = model.decision_function(Xte)
        auc = roc_auc_score(yte, s) if len(np.unique(yte)) == 2 else np.nan
        ap = average_precision_score(yte, s)
        rec = {"model": name, "auc": float(auc), "ap": float(ap)}
        if best is None or rec["auc"] > best["auc"]:
            best = rec
    return best


def run_once(base_seed: int, run_idx: int, n_paths: int, T: int, horizon: int, fast: bool) -> tuple[pd.DataFrame, dict]:
    seed = base_seed + run_idx * 1009
    rng = np.random.default_rng(seed)
    raw = pd.concat([sample_path(rng, T, pid) for pid in range(n_paths)], ignore_index=True)
    df = add_features(raw, horizon)
    splitter = GroupShuffleSplit(n_splits=1, test_size=0.33, random_state=seed)
    tr_idx, te_idx = next(splitter.split(df, df["future_fail"], groups=df["path_id"]))
    train = df.iloc[tr_idx].reset_index(drop=True)
    test = df.iloc[te_idx].reset_index(drop=True)
    ytr = train["future_fail"].astype(int).values
    yte = test["future_fail"].astype(int).values
    if len(np.unique(ytr)) < 2 or len(np.unique(yte)) < 2:
        return pd.DataFrame(), {"run": run_idx, "seed": seed, "degenerate": True}
    rows = []
    for fs, cols in FEATURE_SETS.items():
        res = score_models(train[cols].values, ytr, test[cols].values, yte, seed, fast=fast)
        res.update(run=run_idx, seed=seed, feature_set=fs, n_features=len(cols), test_fail_rate=float(yte.mean()), train_fail_rate=float(ytr.mean()))
        rows.append(res)
    # Shuffled control for combined non-leak.
    ysh = ytr.copy(); rng.shuffle(ysh)
    cols = FEATURE_SETS["combined_physics_plus_cpmf"]
    res = score_models(train[cols].values, ysh, test[cols].values, yte, seed+1, fast=True)
    res.update(run=run_idx, seed=seed, feature_set="combined_physics_plus_cpmf_SHUFFLED", n_features=len(cols), test_fail_rate=float(yte.mean()), train_fail_rate=float(ytr.mean()))
    rows.append(res)
    meta = {
        "run": run_idx, "seed": seed, "degenerate": False,
        "n_windows": int(len(df)), "train_windows": int(len(train)), "test_windows": int(len(test)),
        "future_fail_rate_all": float(df["future_fail"].mean()), "future_fail_rate_test": float(yte.mean()),
    }
    return pd.DataFrame(rows), meta


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", type=str, default="runs/cpmf_qms_smoke_v7_christian_baseline")
    ap.add_argument("--seed", type=int, default=20260607)
    ap.add_argument("--n-runs", type=int, default=8)
    ap.add_argument("--n-paths", type=int, default=45)
    ap.add_argument("--T", type=int, default=16)
    ap.add_argument("--horizon", type=int, default=3)
    ap.add_argument("--full", action="store_true", help="Use slower HGB model too.")
    args = ap.parse_args()

    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    all_scores, metas = [], []
    for r in range(args.n_runs):
        scores, meta = run_once(args.seed, r, args.n_paths, args.T, args.horizon, fast=not args.full)
        metas.append(meta)
        if not scores.empty:
            all_scores.append(scores)
    repeated = pd.concat(all_scores, ignore_index=True) if all_scores else pd.DataFrame()
    if repeated.empty:
        raise SystemExit("All runs were degenerate; increase n_paths/T or adjust thresholds.")
    repeated.to_csv(out / "repeated_scores.csv", index=False)
    pd.DataFrame(metas).to_csv(out / "run_meta.csv", index=False)

    agg = repeated.groupby("feature_set").agg(
        mean_auc=("auc", "mean"), std_auc=("auc", "std"), min_auc=("auc", "min"), max_auc=("auc", "max"),
        mean_ap=("ap", "mean"), std_ap=("ap", "std"), min_ap=("ap", "min"),
        n=("auc", "count"),
        best_model_mode=("model", lambda x: x.mode().iloc[0] if len(x.mode()) else "")
    ).reset_index().sort_values("mean_auc", ascending=False)
    agg.to_csv(out / "aggregate_scores.csv", index=False)

    piv = repeated.pivot_table(index="run", columns="feature_set", values="auc", aggfunc="mean")
    deltas = pd.DataFrame({"run": piv.index})
    if "christian_natural_baseline" in piv and "combined_physics_plus_cpmf" in piv:
        deltas["combined_minus_christian"] = piv["combined_physics_plus_cpmf"] - piv["christian_natural_baseline"]
    if "christian_natural_baseline" in piv and "combined_no_invalidity" in piv:
        deltas["combined_no_invalidity_minus_christian"] = piv["combined_no_invalidity"] - piv["christian_natural_baseline"]
    if "christian_natural_baseline" in piv and "cpmf_relational_extra_only" in piv:
        deltas["cpmf_extra_only_minus_christian"] = piv["cpmf_relational_extra_only"] - piv["christian_natural_baseline"]
    deltas.to_csv(out / "incremental_delta.csv", index=False)

    delta_comb = float(deltas.get("combined_minus_christian", pd.Series(dtype=float)).mean()) if "combined_minus_christian" in deltas else float("nan")
    win_rate_comb = float((deltas["combined_minus_christian"] > 0).mean()) if "combined_minus_christian" in deltas else float("nan")
    delta_noinv = float(deltas.get("combined_no_invalidity_minus_christian", pd.Series(dtype=float)).mean()) if "combined_no_invalidity_minus_christian" in deltas else float("nan")
    win_rate_noinv = float((deltas["combined_no_invalidity_minus_christian"] > 0).mean()) if "combined_no_invalidity_minus_christian" in deltas else float("nan")

    christian_auc = float(agg.loc[agg.feature_set == "christian_natural_baseline", "mean_auc"].iloc[0])
    combined_auc = float(agg.loc[agg.feature_set == "combined_physics_plus_cpmf", "mean_auc"].iloc[0])
    combined_noinv_auc = float(agg.loc[agg.feature_set == "combined_no_invalidity", "mean_auc"].iloc[0])
    shuffled_auc = float(agg.loc[agg.feature_set == "combined_physics_plus_cpmf_SHUFFLED", "mean_auc"].iloc[0])
    position_auc = float(agg.loc[agg.feature_set == "position_only", "mean_auc"].iloc[0])

    if combined_auc > christian_auc + 0.02 and win_rate_comb >= 0.70:
        status = "PASS_INCREMENTAL_CPMF_OVER_CHRISTIAN_BASELINE_SYNTHETIC"
    elif combined_auc > christian_auc and win_rate_comb >= 0.55:
        status = "WEAK_PASS_SMALL_INCREMENTAL_CPMF_OVER_CHRISTIAN_BASELINE"
    else:
        status = "NEG_OR_TIE_CPMF_DOES_NOT_BEAT_CHRISTIAN_BASELINE"

    summary = {
        "status": status,
        "honesty_label": "synthetic qubit Lindblad/QMS-lite; not Christian full QMS; not a theorem",
        "n_runs_requested": args.n_runs,
        "n_runs_scored": int(repeated["run"].nunique()),
        "n_paths": args.n_paths,
        "T": args.T,
        "horizon": args.horizon,
        "mean_auc_christian_natural_baseline": christian_auc,
        "mean_auc_combined_physics_plus_cpmf": combined_auc,
        "mean_auc_combined_no_invalidity": combined_noinv_auc,
        "mean_auc_position_only": position_auc,
        "mean_auc_shuffled": shuffled_auc,
        "mean_delta_combined_minus_christian": delta_comb,
        "win_rate_combined_over_christian": win_rate_comb,
        "mean_delta_combined_no_invalidity_minus_christian": delta_noinv,
        "win_rate_combined_no_invalidity_over_christian": win_rate_noinv,
        "strict_pass_condition": "combined AUC > christian baseline by >0.02 and wins >=70% of runs",
    }
    (out / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    report = [
        "# CPMF/QMS Smoke Test v7 — Christian-natural baseline comparison",
        "",
        f"Status: **{status}**",
        "",
        "## Purpose",
        "v7 asks whether CPMF-style relational generator features add incremental forecast value beyond a stronger domain-natural physics/QMS baseline.",
        "The label is future analytic-regime failure. The main feature sets exclude the diagnostic scalars used to define that label.",
        "",
        "## Key scores",
        f"- Christian-natural baseline mean AUC: {christian_auc:.3f}",
        f"- Combined physics + CPMF mean AUC: {combined_auc:.3f}",
        f"- Combined without raw-invalidity mean AUC: {combined_noinv_auc:.3f}",
        f"- Position-only mean AUC: {position_auc:.3f}",
        f"- Shuffled combined mean AUC: {shuffled_auc:.3f}",
        f"- Combined minus Christian mean delta: {delta_comb:+.3f}",
        f"- Combined win-rate over Christian: {win_rate_comb:.2%}",
        "",
        "## Honest interpretation",
    ]
    if status.startswith("PASS"):
        report += [
            "The CPMF relational additions beat the stronger Christian-natural baseline under the pre-registered synthetic criterion.",
            "This would justify a cautious incremental-signal claim, still only inside the finite QMS-lite harness.",
        ]
    elif status.startswith("WEAK"):
        report += [
            "The CPMF relational additions add a small positive increment, but not enough for a strong promotion.",
            "Treat this as a weak synthetic signal requiring more seeds and a Christian-approved baseline.",
        ]
    else:
        report += [
            "The CPMF relational additions do not reliably beat the stronger Christian-natural baseline.",
            "This is a clean demotion: CPMF is currently organising the admissibility forecast target rather than adding a superior diagnostic beyond good generator physics.",
        ]
    report += [
        "",
        "## Next step",
        "Ask Christian what he would accept as a natural generator-side baseline and rerun this comparison against that feature set and his preferred coercivity/admissibility diagnostics.",
    ]
    (out / "report.md").write_text("\n".join(report), encoding="utf-8")
    print(json.dumps(summary, indent=2))

if __name__ == "__main__":
    main()
