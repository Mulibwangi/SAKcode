#!/usr/bin/env python3
"""
Christian unseen-environment record test v1
===========================================

The two original isospectral Lindblad generators are unchanged.

No classical measurement result is written during the dynamics. At each step,
the system interacts unitarily with a fresh environment qubit. All fragments
remain uninspected until the end. We then ask how much information about the
initial +/- probe branch is recoverable from progressively larger environmental
subsets.

This tests a monotonic irreversible-mixing picture: the record may be dispersed
through the environment even when no distinguished local memory is visible.
"""

from pathlib import Path
import itertools
import json
import math
import numpy as np
import pandas as pd
from scipy.linalg import eigvals

OUT = Path(__file__).resolve().parent

# ---------- Basic operators ----------
I2 = np.eye(2, dtype=complex)
X = np.array([[0, 1], [1, 0]], dtype=complex)
Y = np.array([[0, -1j], [1j, 0]], dtype=complex)
Z = np.array([[1, 0], [0, -1]], dtype=complex)
P1 = {"I": I2, "X": X, "Y": Y, "Z": Z}

def ps(label: str) -> np.ndarray:
    return np.kron(P1[label[0]], P1[label[1]])

I4 = np.eye(4, dtype=complex)
I16 = np.eye(16, dtype=complex)

# Christian pair
J_A = [ps("XI"), ps("ZI"), ps("YI")]
J_C = [ps("XI"), ps("IX"), ps("XX")]
SYSTEMS = {
    "A_anticommuting": J_A,
    "C_commuting_fusion": J_C,
}
PAULI_LABELS = [a + b for a in "IXYZ" for b in "IXYZ" if a + b != "II"]

# ---------- Utilities ----------
def lindblad_super_system(jumps, rates):
    L = np.zeros((16, 16), dtype=complex)
    for J, rate in zip(jumps, rates):
        L += rate * (np.kron(J.conj(), J) - I16)
    return L

def spectrum_error(gamma_c):
    rates = [1.0, 1.0, gamma_c]
    a = np.sort(np.real_if_close(-eigvals(lindblad_super_system(J_A, rates))).real)
    c = np.sort(np.real_if_close(-eigvals(lindblad_super_system(J_C, rates))).real)
    return float(np.max(np.abs(a - c)))

def fixed_residual(jumps, rates, P):
    value = sum(rate * (J @ P @ J - P) for J, rate in zip(jumps, rates))
    return float(np.linalg.norm(value, "fro"))

def pauli_channel_kraus(jumps, rates, dt):
    """
    Exact channel for commuting Pauli conjugation superoperators:
      exp[dt sum_j gamma_j(Ad_J-I)].
    Each factor is a binary random-unitary channel.
    """
    probs = []
    for rate in rates:
        q = math.exp(-2.0 * rate * dt)
        probs.append(((1.0 + q) / 2.0, (1.0 - q) / 2.0))

    kraus = []
    for bits in itertools.product([0, 1], repeat=len(jumps)):
        prob = 1.0
        K = I4.copy()
        for bit, J, (p0, p1_) in zip(bits, jumps, probs):
            prob *= p1_ if bit else p0
            if bit:
                K = J @ K
        if prob > 1e-15:
            kraus.append(math.sqrt(prob) * K)
    return kraus

def apply_system_channel_joint(rho, kraus_system, env_dim):
    Ienv = np.eye(env_dim, dtype=complex)
    out = np.zeros_like(rho)
    for K in kraus_system:
        Kf = np.kron(K, Ienv)
        out += Kf @ rho @ Kf.conj().T
    return (out + out.conj().T) / 2

def env_local_operator(op, qubit_index, n_env):
    result = np.array([[1.0]], dtype=complex)
    for k in range(n_env):
        result = np.kron(result, op if k == qubit_index else I2)
    return result

def interaction_unitary(P, theta, qubit_index, n_env):
    env_dim = 2 ** n_env
    G = np.kron(P, env_local_operator(Y, qubit_index, n_env))
    D = 4 * env_dim
    return math.cos(theta / 2.0) * np.eye(D, dtype=complex) - 1j * math.sin(theta / 2.0) * G

def partial_trace(rho, dims, keep):
    """
    Generic partial trace. keep contains subsystem indices in the original order.
    """
    keep = sorted(keep)
    trace_out = [i for i in range(len(dims)) if i not in keep]
    arr = rho.reshape(dims + dims)
    current_dims = list(dims)
    for idx in sorted(trace_out, reverse=True):
        n = len(current_dims)
        arr = np.trace(arr, axis1=idx, axis2=idx + n)
        current_dims.pop(idx)
    d_keep = int(np.prod(current_dims))
    return arr.reshape((d_keep, d_keep))

def trace_distance(rho, sigma):
    d = (rho - sigma + (rho - sigma).conj().T) / 2
    return float(0.5 * np.sum(np.abs(np.linalg.eigvalsh(d))))

def entropy_bits(rho):
    rho_h = (rho + rho.conj().T) / 2
    vals = np.clip(np.linalg.eigvalsh(rho_h).real, 0.0, None)
    vals = vals[vals > 1e-14]
    return float(-np.sum(vals * np.log2(vals)))

def holevo_bits(rho_plus, rho_minus):
    avg = 0.5 * (rho_plus + rho_minus)
    return entropy_bits(avg) - 0.5 * entropy_bits(rho_plus) - 0.5 * entropy_bits(rho_minus)

def run_case(
    jumps,
    gamma_c,
    probe,
    n_env=4,
    dt=0.16,
    theta=0.55,
    branch_radius=0.8,
):
    rates = [1.0, 1.0, gamma_c]
    env_dim = 2 ** n_env
    zero = np.array([[1, 0], [0, 0]], dtype=complex)
    env0 = zero
    for _ in range(n_env - 1):
        env0 = np.kron(env0, zero)

    rho_plus = np.kron((I4 + branch_radius * probe) / 4.0, env0)
    rho_minus = np.kron((I4 - branch_radius * probe) / 4.0, env0)

    kraus = pauli_channel_kraus(jumps, rates, dt)

    for k in range(n_env):
        rho_plus = apply_system_channel_joint(rho_plus, kraus, env_dim)
        rho_minus = apply_system_channel_joint(rho_minus, kraus, env_dim)

        U = interaction_unitary(probe, theta, k, n_env)
        rho_plus = U @ rho_plus @ U.conj().T
        rho_minus = U @ rho_minus @ U.conj().T
        rho_plus = (rho_plus + rho_plus.conj().T) / 2
        rho_minus = (rho_minus + rho_minus.conj().T) / 2

    dims = [4] + [2] * n_env

    # Local system distinguishability after all mixing.
    sys_plus = partial_trace(rho_plus, dims, keep=[0])
    sys_minus = partial_trace(rho_minus, dims, keep=[0])
    system_td = trace_distance(sys_plus, sys_minus)

    # Prefix fragments: E1, E1E2, ... En. These are nested, so distinguishability
    # cannot decrease when another fragment is included.
    prefix = []
    prev_td = 0.0
    prev_h = 0.0
    for m in range(1, n_env + 1):
        keep = list(range(1, m + 1))
        e_plus = partial_trace(rho_plus, dims, keep=keep)
        e_minus = partial_trace(rho_minus, dims, keep=keep)
        td = trace_distance(e_plus, e_minus)
        h = holevo_bits(e_plus, e_minus)
        prefix.append({
            "fragment_count": m,
            "record_trace_distance": td,
            "record_holevo_bits": h,
            "delta_trace_distance": td - prev_td,
            "delta_holevo_bits": h - prev_h,
        })
        prev_td = td
        prev_h = h

    # Single-fragment recoverability: a simple redundancy indicator.
    singles = []
    for k in range(n_env):
        e_plus = partial_trace(rho_plus, dims, keep=[1 + k])
        e_minus = partial_trace(rho_minus, dims, keep=[1 + k])
        singles.append({
            "fragment": k + 1,
            "trace_distance": trace_distance(e_plus, e_minus),
            "holevo_bits": holevo_bits(e_plus, e_minus),
        })

    return {
        "fixed_probe": fixed_residual(jumps, rates, probe) < 1e-10,
        "fixed_residual": fixed_residual(jumps, rates, probe),
        "system_trace_distance": system_td,
        "prefix": prefix,
        "singles": singles,
        "prefix_td_monotone": all(x["delta_trace_distance"] >= -1e-11 for x in prefix),
        "prefix_holevo_monotone": all(x["delta_holevo_bits"] >= -1e-11 for x in prefix),
        "full_environment_td": prefix[-1]["record_trace_distance"],
        "full_environment_holevo": prefix[-1]["record_holevo_bits"],
        "mean_single_td": float(np.mean([x["trace_distance"] for x in singles])),
        "mean_single_holevo": float(np.mean([x["holevo_bits"] for x in singles])),
    }

def main():
    gamma_values = [0.05, 1.0, 20.0]
    n_env = 4
    dt = 0.16
    theta = 0.55
    branch_radius = 0.8

    final_rows = []
    prefix_rows = []
    single_rows = []

    for gamma_c in gamma_values:
        for probe_label in PAULI_LABELS:
            probe = ps(probe_label)
            for system_name, jumps in SYSTEMS.items():
                result = run_case(
                    jumps,
                    gamma_c,
                    probe,
                    n_env=n_env,
                    dt=dt,
                    theta=theta,
                    branch_radius=branch_radius,
                )

                final_rows.append({
                    "gamma_c": gamma_c,
                    "probe": probe_label,
                    "system": system_name,
                    "fixed_probe": int(result["fixed_probe"]),
                    "fixed_residual": result["fixed_residual"],
                    "system_trace_distance": result["system_trace_distance"],
                    "full_environment_td": result["full_environment_td"],
                    "full_environment_holevo": result["full_environment_holevo"],
                    "mean_single_td": result["mean_single_td"],
                    "mean_single_holevo": result["mean_single_holevo"],
                    "prefix_td_monotone": int(result["prefix_td_monotone"]),
                    "prefix_holevo_monotone": int(result["prefix_holevo_monotone"]),
                    "spectrum_pair_error": spectrum_error(gamma_c),
                })

                for row in result["prefix"]:
                    prefix_rows.append({
                        "gamma_c": gamma_c,
                        "probe": probe_label,
                        "system": system_name,
                        "fixed_probe": int(result["fixed_probe"]),
                        **row,
                    })

                for row in result["singles"]:
                    single_rows.append({
                        "gamma_c": gamma_c,
                        "probe": probe_label,
                        "system": system_name,
                        "fixed_probe": int(result["fixed_probe"]),
                        **row,
                    })

    final_df = pd.DataFrame(final_rows)
    prefix_df = pd.DataFrame(prefix_rows)
    single_df = pd.DataFrame(single_rows)

    final_df.to_csv(OUT / "christian_unseen_environment_final_v1.csv", index=False)
    prefix_df.to_csv(OUT / "christian_unseen_environment_prefix_v1.csv", index=False)
    single_df.to_csv(OUT / "christian_unseen_environment_single_fragments_v1.csv", index=False)

    group = (
        final_df.groupby(["system", "fixed_probe"])[
            [
                "system_trace_distance",
                "full_environment_td",
                "full_environment_holevo",
                "mean_single_td",
                "mean_single_holevo",
            ]
        ]
        .mean()
        .reset_index()
    )
    group.to_csv(OUT / "christian_unseen_environment_group_summary_v1.csv", index=False)

    # Pairwise A/C algebra-owner recovery on asymmetric fixed directions.
    pivot = final_df.pivot_table(
        index=["gamma_c", "probe"],
        columns="system",
        values=[
            "fixed_probe",
            "full_environment_td",
            "full_environment_holevo",
            "mean_single_td",
        ],
    )
    pivot.columns = [f"{metric}__{system}" for metric, system in pivot.columns]
    pair = pivot.reset_index()

    pair["fixed_owner"] = np.select(
        [
            (pair["fixed_probe__A_anticommuting"] == 1)
            & (pair["fixed_probe__C_commuting_fusion"] == 0),
            (pair["fixed_probe__A_anticommuting"] == 0)
            & (pair["fixed_probe__C_commuting_fusion"] == 1),
            (pair["fixed_probe__A_anticommuting"] == 1)
            & (pair["fixed_probe__C_commuting_fusion"] == 1),
        ],
        ["A_only", "C_only", "shared"],
        default="neither",
    )
    pair["env_td_A_minus_C"] = (
        pair["full_environment_td__A_anticommuting"]
        - pair["full_environment_td__C_commuting_fusion"]
    )
    pair["env_holevo_A_minus_C"] = (
        pair["full_environment_holevo__A_anticommuting"]
        - pair["full_environment_holevo__C_commuting_fusion"]
    )
    pair["single_td_A_minus_C"] = (
        pair["mean_single_td__A_anticommuting"]
        - pair["mean_single_td__C_commuting_fusion"]
    )

    asym = pair[pair["fixed_owner"].isin(["A_only", "C_only"])].copy()
    for metric in ["env_td_A_minus_C", "env_holevo_A_minus_C", "single_td_A_minus_C"]:
        asym[f"pred_{metric}"] = np.where(asym[metric] > 0, "A_only", "C_only")

    acc_env_td = float(np.mean(asym["pred_env_td_A_minus_C"] == asym["fixed_owner"]))
    acc_env_h = float(np.mean(asym["pred_env_holevo_A_minus_C"] == asym["fixed_owner"]))
    acc_single = float(np.mean(asym["pred_single_td_A_minus_C"] == asym["fixed_owner"]))

    pair.to_csv(OUT / "christian_unseen_environment_pairwise_v1.csv", index=False)

    # Prefix curves averaged by fixed status.
    prefix_group = (
        prefix_df.groupby(["fixed_probe", "fragment_count"])[
            ["record_trace_distance", "record_holevo_bits"]
        ]
        .mean()
        .reset_index()
    )
    prefix_group.to_csv(OUT / "christian_unseen_environment_prefix_summary_v1.csv", index=False)

    summary = {
        "construction": (
            "No classical outcome during evolution. The system interacts unitarily "
            "with four fresh environment qubits; all fragments are inspected only "
            "after the full process."
        ),
        "n_environment_fragments": n_env,
        "dt": dt,
        "interaction_theta": theta,
        "branch_radius": branch_radius,
        "gamma_values": gamma_values,
        "n_probes": len(PAULI_LABELS),
        "n_cases": int(len(final_df)),
        "max_spectrum_pair_error": float(final_df["spectrum_pair_error"].max()),
        "fraction_prefix_td_monotone": float(final_df["prefix_td_monotone"].mean()),
        "fraction_prefix_holevo_monotone": float(
            final_df["prefix_holevo_monotone"].mean()
        ),
        "fixed_means": {
            "system_trace_distance": float(
                final_df[final_df["fixed_probe"] == 1]["system_trace_distance"].mean()
            ),
            "full_environment_td": float(
                final_df[final_df["fixed_probe"] == 1]["full_environment_td"].mean()
            ),
            "full_environment_holevo": float(
                final_df[final_df["fixed_probe"] == 1]["full_environment_holevo"].mean()
            ),
            "mean_single_td": float(
                final_df[final_df["fixed_probe"] == 1]["mean_single_td"].mean()
            ),
        },
        "nonfixed_means": {
            "system_trace_distance": float(
                final_df[final_df["fixed_probe"] == 0]["system_trace_distance"].mean()
            ),
            "full_environment_td": float(
                final_df[final_df["fixed_probe"] == 0]["full_environment_td"].mean()
            ),
            "full_environment_holevo": float(
                final_df[final_df["fixed_probe"] == 0]["full_environment_holevo"].mean()
            ),
            "mean_single_td": float(
                final_df[final_df["fixed_probe"] == 0]["mean_single_td"].mean()
            ),
        },
        "asymmetric_owner_accuracy_full_env_td": acc_env_td,
        "asymmetric_owner_accuracy_full_env_holevo": acc_env_h,
        "asymmetric_owner_accuracy_mean_single_td": acc_single,
        "group_means": group.to_dict(orient="records"),
        "prefix_means": prefix_group.to_dict(orient="records"),
    }

    (OUT / "christian_unseen_environment_summary_v1.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )

    report = f"""# Christian unseen-environment record test v1

## Construction

The original two isospectral Lindblad generators were not modified.

No measurement result was written during the dynamics. The system interacted
unitarily with four fresh environment qubits. All fragments remained uninspected
until the end. We then measured recoverability from one fragment, two fragments,
three fragments and the full environment.

## Spectral control

Maximum A-versus-C spectrum discrepancy:

**{summary['max_spectrum_pair_error']:.3e}**

## Monotonic recovery

- Prefix trace distance monotone in:
  **{summary['fraction_prefix_td_monotone']:.1%}** of cases.
- Prefix Holevo information monotone in:
  **{summary['fraction_prefix_holevo_monotone']:.1%}** of cases.

This monotonicity is not imposed by a classical write step. It follows from
inspecting progressively larger portions of the final quantum environment.

## Fixed directions

Mean final values:

| Quantity | Fixed directions | Nonfixed directions |
|---|---:|---:|
| Distinction still local in system | {summary['fixed_means']['system_trace_distance']:.6f} | {summary['nonfixed_means']['system_trace_distance']:.6f} |
| Full-environment trace distance | {summary['fixed_means']['full_environment_td']:.6f} | {summary['nonfixed_means']['full_environment_td']:.6f} |
| Full-environment Holevo information | {summary['fixed_means']['full_environment_holevo']:.6f} | {summary['nonfixed_means']['full_environment_holevo']:.6f} |
| Mean single-fragment trace distance | {summary['fixed_means']['mean_single_td']:.6f} | {summary['nonfixed_means']['mean_single_td']:.6f} |

## Hidden-algebra recovery

On directions fixed in only one generator:

- full-environment trace distance identified the correct algebra owner in
  **{acc_env_td:.1%}** of cases;
- full-environment Holevo information identified it in
  **{acc_env_h:.1%}**;
- the average individual fragment identified it in
  **{acc_single:.1%}**.

## Verdict

The record need not be stored in a singled-out classical memory. It can exist as
distributed quantum correlations across an unobserved environment and become
recoverable only when sufficiently many fragments are collected.

The two generators remain spectrally identical, but their different fixed-point
algebras determine which operator distinctions survive locally and which seed a
strong distributed environmental record.

This is an operational model of irreversible record dispersal. It does not prove
Semantic Admissibility or a new fundamental ZipTie law.
"""
    (OUT / "christian_unseen_environment_report_v1.md").write_text(
        report, encoding="utf-8"
    )

    print(json.dumps(summary, indent=2))
    print("\nPrefix means:")
    print(prefix_group.to_string(index=False))
    print("\nAsymmetric cases:")
    print(
        asym[
            [
                "gamma_c",
                "probe",
                "fixed_owner",
                "env_td_A_minus_C",
                "env_holevo_A_minus_C",
                "single_td_A_minus_C",
            ]
        ].to_string(index=False)
    )
    print("\nFiles:")
    for name in [
        "christian_unseen_environment_report_v1.md",
        "christian_unseen_environment_summary_v1.json",
        "christian_unseen_environment_final_v1.csv",
        "christian_unseen_environment_prefix_v1.csv",
        "christian_unseen_environment_single_fragments_v1.csv",
        "christian_unseen_environment_group_summary_v1.csv",
        "christian_unseen_environment_pairwise_v1.csv",
        "christian_unseen_environment_prefix_summary_v1.csv",
    ]:
        print("-", OUT / name)

if __name__ == "__main__":
    main()
