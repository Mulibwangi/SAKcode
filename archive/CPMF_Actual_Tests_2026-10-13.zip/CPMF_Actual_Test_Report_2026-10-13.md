# CPMF — Actual test report

Prepared for David Lee · 13 October 2026

**Result:** the executable tests support explicit recovery maps, independent referent checks, conditional robustness bounds, and richer witnesses for isospectral structures. They do not establish the quoted semantic-energy identity, a universal TAS product, or a connection that proves the Yang–Mills mass gap. The application benchmark shows a small, uncertain predictive increment.

## What was actually executed

Twelve test groups were specified before running the new suite. The packet contains the frozen protocol, source hashes, runnable Python, computed JSON and CSV outputs, and a figure. These are mathematical counterexamples and numerical experiments on declared synthetic substrates. There was no VLM inference, poisoned-model training, physical energy measurement, or four-dimensional Yang–Mills simulation.

The original v7 QMS forecast harness and original 90-case environment-record construction were recovered and executed. Their numerical source files were preserved. A separate wrapper corrected the forecasting evaluation: models were selected on validation data, and entire unseen paths were reserved for the final test. All new numerical assertions completed successfully.

## Verdicts at a glance

| Claim or mechanism | Executed result | Status earned |
|---|---|---|
| An adjoint supplies general round-trip recovery | For \(T=2I\), adjoint recovery had relative error 3; inverse recovery had error 0 | False without an isometry or other sufficient assumption |
| Exact round trips define meaning | A label swap had zero cycle error and zero accuracy against the independently declared labels | Round trips alone are insufficient |
| Perturbations expose an unstable transport bridge | Inverse gain rose from 1 to \(10^8\) as the smallest singular value fell from 1 to \(10^{-8}\) | Valid linear diagnostic, requiring a declared metric |
| \(E_s=\theta_s^2\dot\kappa\) is an invariant positive energy identity | Expression changed sign and changed by a factor of 10 under \(s=10t\); a separate historical path cost was positive while this expression was zero | Fails that interpretation; no independently calibrated replacement established |
| TAS is a universal quantitative law | Equal marginal gate probabilities gave joint success probabilities 0, 1/8 and 1/2 | Marginal product is not universal; conditional chain rule is exact |
| Refinement necessarily destroys earlier admissibility | Shrinking intervals did; finer nested grids preserved the old state exactly | Conditional failure mode, not a law of all refinement |
| Zip-Tie protects coherent meaning | Guard had zero violations in 5,000 proposals; a decreasing proxy separately worsened referent error from 0 to 0.998 | Score protection works; referent protection needs its own witness |
| Positive spectra of \(T^\dagger T\) and \(TT^\dagger\) agree | Maximum relative discrepancy \(1.53\times10^{-15}\) across 1,000 maps | Standard scoped mathematical fact reproduced |
| Spectra determine fixed-point algebra structure | Original generators remained isospectral, but commutator witnesses distinguished their algebras | Spectrum alone is insufficient; richer witness succeeded |
| CPMF features improve the application reliably | Mean held-out AUC 0.8989 → 0.9053; paired interval includes zero | Small uncertain increment; locked promotion rule failed |
| A finite positive spectral gap establishes a mass gap | Positive graph gaps fell toward zero as volume increased | Inference fails; physical Yang–Mills bridge remains unconstructed |
| BadSem ASR was independently replicated | Paper verified; model/dataset replication not executed | External reported result only |

## 1. Round-trip recovery needs a recovery operation

Write \(B:\mathcal M_C\to\mathcal M_P\) for recovery. This avoids reusing David's \(R\), which denotes relational determination arising from \(A\wedge Co\).

\[
\mathcal C=T\mathcal P,\qquad
\widehat{\mathcal P}=B\mathcal C,\qquad
r_{\rm cyc}(\mathcal P)=\|BT\mathcal P-\mathcal P\|.
\]

For \(T=2I\), \(T^\dagger=2I\) and \(T^\dagger T=4I\). Consequently the relative cycle error is 3 for every nonzero input. In contrast, \(B=T^{-1}=\frac12 I\) recovers exactly. The idempotency defect of \(T^\dagger T\) is 12 in operator norm: it is not automatically a closure operator.

All 100 orthogonal positive controls recovered within \(1.10\times10^{-15}\) relative error. A projection discarding a third coordinate had full-state error 0.9526 while preserving the declared first two coordinates exactly. Legitimate information loss must therefore be scored against what the seam promises to preserve.

The label-swap counterexample is decisive for sufficiency. Both forward and backward maps can agree perfectly with each other while disagreeing with an external referent. The swap recovered both inputs exactly, yet assigned both forward labels incorrectly.

The repair is to retain **two distinct checks**: recoverability of the declared information and agreement with the declared referent. Neither failure of an arbitrarily chosen recovery map nor success of a round trip proves whether an entity physically exists.

## 2. Brittleness survives as a defined diagnostic

The test used

\[
T_\varepsilon=\begin{pmatrix}1&0\\0&\varepsilon\end{pmatrix},
\quad \mathcal P=(1,0),
\quad \delta\mathcal C=(0,10^{-6}).
\]

Inverse recovery produced \(\delta\mathcal P=(0,10^{-6}/\varepsilon)\). The computed amplification matched \(1/\varepsilon\) throughout the nine-point sweep. At \(\varepsilon=10^{-8}\), a perturbation of size \(10^{-6}\) produced reconstruction error 100 and an angular error close to \(\pi/2\).

This establishes sensitivity in that linear model. It does not by itself establish that a particular VLM loses user intent.

There is also a coordinate trap. An unchanged angle of 0.1 radians became 1.47146 radians when coordinates were scaled anisotropically and ordinary Euclidean angles were recomputed. Transforming the metric restored 0.1. Across 300 random charts, the maximum metric-corrected angular discrepancy was \(7.82\times10^{-14}\); weighted adjoints agreed with transformed originals within \(4.51\times10^{-13}\) relative error.

An angular \(\theta_{\rm sem}\) diagnostic must specify the embeddings, reference pair, normalization and metric. It must not be silently equated with an intrinsic curvature.

## 3. The quoted energy formula does not earn its claimed status

The earlier project record already quarantined this formula. Retrieved discussions use several competing quantities: angular error, integrated squared angular velocity, curvature penalties, and proposed dissipative couplings. They are not interchangeable definitions of a measured energy.

For the specific expression in the pasted output:

- With \(\theta=0.2\) and \(\kappa=0.5+0.25\sin t\), the computed expression ranges from −0.01 to +0.01. It cannot be assumed to be a nonnegative maintenance cost.
- Under \(s=10t\), its value at the same point changes from 0.01 to 0.001. It behaves as a rate under this reparameterization, not as a parameter-independent scalar energy.
- If both gauges are dimensionless, its units are inverse time. Calling it physical energy requires a dimensioned coefficient or a different dimensional definition.
- For \(\theta(t)=0.2+0.1\sin t\) and constant \(\kappa\), the historical path-cost proxy \(\int_0^{2\pi}\dot\theta^2dt\) is 0.0314159, while the quoted expression is identically zero. Thus the proposed identity is not an identity between those two independently specified constructions.
- Doubling \(\theta\) multiplies its square by 4. Quadratic growth is not exponential growth.

Signed energy differences or model-specific rate laws are possible. These counterexamples reject the supplied *general positive invariant energy* interpretation; they do not rule out every coupling one could define after adding assumptions. Introducing an absolute value addresses the sign issue alone. It does not supply an empirical calibration, a geometric metric, a physical Hamiltonian or a theorem.

## 4. Refinement and Zip-Tie need separate commitments

For a state \(x_0=0.75\) and admissible sets \(A_n=[-1/n,1/n]\), the minimum distortion is

\[
d(x_0,A_n)=\max(0,0.75-1/n).
\]

The computed distortion rose to 0.734375 at \(n=64\). That is a real consequence of the declared shrinking sets. In the positive control, grids of spacing \(0.25/n\) became finer while preserving \(x_0\) exactly at every level. Refinement need not shrink admissibility.

The bounded-backslip guard accepted 778 of 5,000 proposals with allowance 0.001 and no violations. This is useful implementation behavior. It follows from the acceptance rule and supplies no independent evidence of a universal ratchet law.

A separate trajectory reduced the proxy \(x^2\) from 1 to \(9.54\times10^{-7}\) while increasing the referent error \((x-1)^2\) from 0 to 0.99805. Protecting an objective can protect the wrong thing. A seam specification must say which reference, relation or observable remains binding when the representation or objective changes.

## 5. TAS needs dependence or calibrated conditional gauges

Each world used 100,000 generated observations. The three marginal gate probabilities were analytically 1/2.

| Gate dependence | Exact joint success | Observed joint success | Observed marginal product |
|---|---:|---:|---:|
| Independent | 0.125 | 0.12648 | 0.12571 |
| Perfectly correlated | 0.500 | 0.50234 | 0.12676 |
| First two disjoint | 0.000 | 0.00000 | 0.12522 |

For literal probabilities the exact statement is

\[
\Pr(T_g\cap A_g\cap S_g)
=\Pr(T_g)\Pr(A_g\mid T_g)\Pr(S_g\mid T_g\cap A_g).
\]

The computed conditional products matched observed joint success to floating-point precision. A product of marginal probabilities requires the relevant factorization; pairwise independence alone is not enough in general.

If \(\tau,\alpha,\sigma\) are scores rather than probabilities, their scales and relation to independently measured understanding still need calibration. Multiplication can remain a chosen bottleneck score; this test does not validate it as a universal law of understanding.

## 6. Interaction, gauge and projector controls

Across 1,000 rectangles, the normalized mixed difference for \(\sin t+r^2\) was at most \(2.80\times10^{-14}\). Adding \(0.5tr\) produced the expected interaction 0.5, with error at most \(1.88\times10^{-14}\). These checks distinguish separability from interaction in a scalar response. They do not compute intrinsic Riemannian curvature.

Across 300 simultaneous unitary changes of state and observable, the maximum change of expectation was \(2.00\times10^{-15}\). A projector update performed while holding the laboratory observable fixed changed its expectation from 1 to 0. A representation change and a state update therefore have different operational signatures. Nothing in this test establishes that physical randomness or nonlocality is an illusion, or selects an interpretation of quantum measurement.

## 7. The isospectral witness is useful structural gold

The original generators use the jump families

\[
J_A=\{X\otimes I,Z\otimes I,Y\otimes I\},\qquad
J_C=\{X\otimes I,I\otimes X,X\otimes X\}.
\]

They have identical spectra for the tested rate choices, with maximum discrepancy \(5.68\times10^{-14}\). Their fixed-point spaces have the same dimension but different multiplication structures: the first contains a noncommutative matrix algebra on the second factor; the second is commutative.

The new witness recovered the lowest four singular vectors of the full generator and measured commutators of the recovered basis matrices. Its classification threshold, 0.2, was locked before execution.

| Algebra | Noise operator norm | Correct classifications | Observed commutator range |
|---|---:|---:|---:|
| Noncommutative | 0 | 200/200 | 0.7694–0.9988 |
| Commutative | 0 | 200/200 | approximately \(10^{-16}\)–\(10^{-14}\) |
| Noncommutative | 0.01 | 200/200 | 0.7295–0.9940 |
| Commutative | 0.01 | 200/200 | 0.000978–0.001884 |

These 800 matrix cases support the declared witness at the tested noise scale. The rank-four prior and access to the full generator are material assumptions. The noisy operator perturbation models measurement error; it is not claimed to remain a valid Lindblad generator.

The original 90-case environment-record simulation also reran successfully. Prefix trace distance and Holevo information were monotone in all cases. Each of the recorded algebra-owner criteria succeeded on all asymmetric cases. This remains numerical simulation with chosen probe interactions and exact access to output density matrices.

This is a different test from the earlier random-probe v4 algebra classifier. It does not erase that classifier's recorded robustness failure. Nor is successful algebra recovery positive detection of SA.

## 8. Application effectiveness: a small uncertain increment

The original default rerun produced a weak positive score:

| Original v7 configuration | Mean AUC |
|---|---:|
| Domain-natural physics baseline | 0.86865 |
| Physics plus CPMF features | 0.87936 |
| Combined, excluding raw invalidity | 0.87974 |
| Shuffled training labels | 0.48530 |

The increment was +0.01071, with wins in 6/8 runs. This is a new execution of the saved defaults, not reproduction of an unidentified earlier run configuration. It does not justify rewriting every historical negative as positive.

Inspection found that the original chooses between logistic regression and a random forest using their **test** AUC. This makes its reported selected scores optimistic. It also retains incomplete future windows near each path's end.

The corrected test generated 1,400 fresh paths across 20 datasets, used only complete four-step future windows, and separated 34 fit paths, 12 validation paths and 24 test paths per run. Model selection used validation AUC only. The final evaluation scored 7,680 unseen-path windows. No run was skipped.

| Corrected evaluation | Mean test AUC | Mean average precision |
|---|---:|---:|
| Physics baseline | 0.89890 | 0.74502 |
| Physics plus CPMF | 0.90526 | 0.75927 |
| Combined, excluding raw invalidity | 0.90808 | 0.76642 |
| Time-only control | 0.51515 | 0.25167 |
| Shuffled training labels | 0.50113 | 0.26717 |

| Paired comparison with physics | Mean AUC increment | Paired bootstrap 95% interval | Win fraction |
|---|---:|---:|---:|
| Combined | +0.00636 | [−0.00577, +0.01795] | 65% |
| Combined without invalidity | +0.00919 | [−0.00276, +0.02243] | 80% |

Neither passed the locked requirement of increment greater than 0.02, wins in at least 70% of runs, and an interval wholly above zero. The correct conclusion is **a small uncertain gain in this generator**, not proof of no possible gain. The controls behave as expected.

Original and corrected absolute scores use different sample sizes and horizon settings; their difference cannot isolate the effect of fixing model selection. The paired comparisons within each configuration are the relevant quantities. Intervals describe Monte Carlo variability under this synthetic generator, not reliability across physical systems or VLMs.

## 9. What the spectral frontier can legitimately say

For an injective linear map between specified Hilbert spaces,

\[
T^\dagger T\succeq b^2 I
\quad\Longrightarrow\quad
\|T^+\delta\mathcal C\|\le \frac{\|\delta\mathcal C\|}{b}.
\]

This is a conditional robustness statement. Across 500 perturbation trials, the original smallest singular value was 0.3 and perturbation operator norm was 0.05. The lower singular-value bound was therefore 0.25 and the inverse-gain bound 4. The smallest observed value was 0.26860; the largest observed inverse gain was 3.72308.

Positive spectra of the two Gram operators agreed across all 1,000 complex rectangular/square maps. That agreement does not identify them with a Hamiltonian or determine their fixed-point algebras.

The family \(T_\varepsilon=\operatorname{diag}(1,\varepsilon)\) has positive Gram gap \(\varepsilon^2\) at every \(\varepsilon>0\), yet the gap tends to zero. Exact inverse round trips still exist for every member.

For a massless cycle graph at fixed lattice spacing,

\[
\lambda_1(N)=4\sin^2(\pi/N)\longrightarrow0.
\]

Computed gaps fell from 0.585786 at \(N=8\) to 0.000150596 at \(N=512\). In the fixed-length, refined-grid control, \(N^2\lambda_1(N)\) instead approached \(4\pi^2\). Fixing the physical domain and increasing volume are distinct limits.

A fixed positive quadratic form also has arbitrarily small cost as its input amplitude tends to zero. A Rayleigh gap gives a lower bound relative to squared norm, not a minimum absolute cost for every nonzero input. Even a genuine gapped quantum Hamiltonian admits arbitrarily small positive energy expectations in superpositions close to the vacuum; the spectral gap is a statement about the spectrum above the vacuum.

The [Jaffe–Witten problem statement](https://www.claymath.org/wp-content/uploads/2022/06/yangmills.pdf) requires a nontrivial quantum Yang–Mills theory on \(\mathbb R^4\), appropriate axiomatic properties, and a positive physical spectral gap. No mapping from the CPMF operators to that physical theory was provided. [Clay's current page](https://www.claymath.org/millennium/yang-mills-the-maths-gap/) still lists the problem as unsolved.

The defensible connection is a shared *question about uniform coercivity*. A Yang–Mills conclusion would additionally require a justified physical operator correspondence, vacuum treatment, physical scales, and control of the relevant limits. The executed families show why a finite gap cannot substitute for those requirements.

## 10. BadSem: checked source, unreplicated experiment

The [original BadSem paper, arXiv:2506.07214v1](https://arxiv.org/html/2506.07214v1), reports average attack success above 98% across four evaluated VLM variants using poisoned image–text semantic mismatches. Its tested system prompting and small clean-data fine-tuning were inadequate defenses.

“Completely bypassing” is too strong as a summary of all defenses: the authors report some reduction from their limited fine-tuning experiment, with substantial residual attack success. The result is scoped to the evaluated poisoning, datasets, models and defenses.

No supplied checkpoint, SIMBad evaluation data or model inference runtime was available for replication here. No claim that CPMF detects or defeats BadSem was tested. Such a defense claim would require independent mismatch annotations, benign mismatch controls, clean-task utility, matched ordinary baselines, and untouched poisoned-model evaluation data.

## Status to carry forward

Retain the seam as an explicit contract: named referent, participating spaces, declared forward and recovery maps, admissibility, lawful closure, coherence constraints, tolerances, and an independently scored witness. Retain singular-value robustness and the spectrum-versus-algebra distinction within their stated models.

Keep the energy identity, universal TAS interpretation and physical mass-gap bridge outside the established core. The current forecasting evidence is insufficient for a reliable incremental-effectiveness claim. Calling \(\mathcal M_P\) unconstrained, or declaring that all reality follows from a round trip, was not established by any of these experiments.

The test packet permits further runs without guessing what was actually done. It preserves the older sources and recorded negatives while adding this dated result.

