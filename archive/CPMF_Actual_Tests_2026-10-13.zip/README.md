# CPMF actual tests — 13 October 2026

Start with `CPMF_Actual_Test_Report_2026-10-13.md`. The locked protocol is
`CPMF_test_protocol_2026-10-13.md`. Computed numbers are in `audit_results`.

The two files in `original_sources` were recovered from the saved CPMF project
and are unchanged. Their hashes are recorded. Original environment outputs are
in `audit_results/original_environment`; original forecast outputs are in
`audit_results/original_v7`.

The numerical tests are mathematical and synthetic. BadSem was source-checked
without model replication. No physical Yang–Mills theory was constructed.

## Reproduce

Use Python 3.12 with the packages in `requirements.txt`. From this directory:

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 python3 run_cpmf_audit.py
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 python3 run_qms_validation_audit.py
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 python3 original_sources/cpmf_qms_smoke_test_v7_christian_baseline.py --out audit_results/original_v7 --seed 20260607 --n-runs 8 --n-paths 45 --T 16 --horizon 3
```

The second runner also executes the original environment construction, changing
only its output directory. The report records this execution; rerunning the
scripts updates numeric output files without rewriting the narrative report.

Versions, seeds and hashes are recorded in `audit_results/metadata.json` and
`audit_results/qms_validation_summary.json`. `qms_validation_splits.json`
lists fit/validation/test path IDs. No model is selected on the corrected test
set. `audit_overview.png` is a static figure of the executed controls.
